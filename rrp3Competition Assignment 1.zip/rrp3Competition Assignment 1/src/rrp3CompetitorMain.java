public class rrp3CompetitorMain {

	public static void main(String[] arg) {
		rrp3CompetitorManager Manager = new rrp3CompetitorManager();
		Manager.run();
	}

}
