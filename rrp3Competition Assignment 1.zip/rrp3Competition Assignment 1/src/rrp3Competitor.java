import java.util.Arrays;

public class rrp3Competitor {

	// Assign parameters

	private int competitorNumber;
	private Name competitorName;
	private String competitorLevel;
	private int competitorAge;
	private String competitorCountry;
	private int[] gameScores;

	public rrp3Competitor(int competitorNumber, Name competitorName, String competitorLevel, int competitorAge,
			String competitorCountry, int[] gameScores) {

		this.competitorNumber = competitorNumber;
		this.competitorName = competitorName;
		this.competitorLevel = competitorLevel;
		this.competitorAge = competitorAge;
		this.competitorCountry = competitorCountry;
		this.gameScores = gameScores;

	}

	// create get and set methods for the parameters listed in the constructor

	public int getcompetitorNumber() {
		return competitorNumber;
	}

	public void setcompetitorNumber(int competitorNumber) {
		this.competitorNumber = competitorNumber;
	}

	public Name getName() {
		return competitorName;
	}

	public void setcompetitorName(Name competitorName) {
		this.competitorName = competitorName;
	}

	public String getcompetitorLevel() {
		return competitorLevel;
	}

	public void setcompetitorLevel(String competitorLevel) {
		this.competitorLevel = competitorLevel;
	}
	
	

	public int getcompetitorAge() {
		return competitorAge;
	}

	public void setcompetitorAge(int competitorAge) {
		this.competitorAge = competitorAge;
	}

	public String getcompetitorCountry() {
		return competitorCountry;
	}

	public void setcompetitorCountry(String competitorCountry) {
		this.competitorCountry = competitorCountry;
	}

	public void setgameScores(int[] gameScores) {
		this.gameScores = gameScores;
	}

	
	// method to print the score array
	public String getarrayofgameScores() {
		return Arrays.toString(gameScores);
	}

	// method to generate average from array
	public double getAveragescore(int[] gameScores) {

		int sum = 0;
		double average = 0;
		for (int i = 0; i < gameScores.length; i++)
			sum = sum + gameScores[i];
		average = sum / gameScores.length;
		return average;
	}

	// weighted average score
	public double getweightedAverage() {
		double weightedAverage;

		{

			if (competitorLevel.equals("Professional")) {
				weightedAverage = getAveragescore(gameScores) * 1.75;

			} else if (competitorLevel.equals("Veteran")) {
				weightedAverage = getAveragescore(gameScores) * 1.5;

			} else {
				weightedAverage = getAveragescore(gameScores) * 1.25;

			}

		}

		return weightedAverage;
	}

	// create get Full details method
	public String getfullDetails() {

		return "Competitor number " + competitorNumber + ", " + "name " + competitorName.getFullName() + ".\n"
				+ competitorName.getfirstName() + " is a " + competitorLevel + " aged " + competitorAge + " from " + competitorCountry + " and received these scores: "
				+ getarrayofgameScores().replace("[", " ").replace("]", " ") + "\nThis gives them an overall score of "
				+ getweightedAverage() + ".";
	}

	// create a method to get short details
	public String getshortDetails() {

		return "CN " + competitorNumber + " (" + competitorName.getInititals() + ") " + "has overall score "
				+ getweightedAverage() + ".";
	}





	// public String getnameofWinner() {

	// return competitorName.getFullName() + "is the winner of Battle Of Wits.";

	// }

}