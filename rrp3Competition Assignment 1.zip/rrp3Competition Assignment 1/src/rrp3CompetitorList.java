import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

//import statements
/**
 * @author Rachana Patel email: rrp3@hw.ac.uk
 * @version 3.6 (current version number of program)
 * @since 3.0 (the version of the package this class was first added to)
 */

public class rrp3CompetitorList {

	private ArrayList<rrp3Competitor> competitorList;

	private Scanner scanner;

	// create an empty array list
	public rrp3CompetitorList() {
		competitorList = new ArrayList<rrp3Competitor>();
	}

	/**
	 * 
	 * @param c is the competitor to be added to competitor list
	 */
	public void add(rrp3Competitor c) {
		competitorList.add(c);
	}

	/**
	 * Reads specified files, extracts competitor information, creating competitor
	 * objects Add the information to list of competitors
	 * 
	 * @param filename is the name of the input file
	 * @exception FileNotFoundException if the file does not exists
	 */

	public void readFile(String filename) {
		try {
			File f = new File("rrp3CompetitorInput");
			scanner = new Scanner(f);
			while (scanner.hasNextLine()) {
				String inputLine = scanner.nextLine();
				if (inputLine.length() != 0) {
					processLine(inputLine);
				}

			}

		} catch (FileNotFoundException fnf) {
			System.out.println(filename + " not found ");
			System.exit(0);
		}
	}

	/**
	 * Supplied text to writer to write a report
	 * 
	 * @return report with competitor information
	 */

	// method to create report with one line per person
	public String getAllCompetitors() {
		String report = "";

		for (rrp3Competitor c : competitorList) {

			report += String.format("%-10d", c.getcompetitorNumber());

			report += String.format("%-30s", c.getName().getFullName());

			report += String.format("%-15s", c.getcompetitorLevel());

			report += String.format("%-4d", c.getcompetitorAge());

			report += String.format("%-10s", c.getcompetitorCountry());

			report += c.getarrayofgameScores().replace("[", " ").replace("]", " ");

			report += "     ";

			report += Double.toString(c.getweightedAverage());

			report += "\n";
		}
		return report;
	}

	/**
	 * Process line, extracts information and creates Competitor object
	 * 
	 * @exception NumberFormatException          if unable to format string to
	 *                                           number.
	 * @exception ArrayIndexOutOfBoundsException if the array index does not exist.
	 * @param line the line processed from input file
	 */

	// create method to process line from the input file
	private void processLine(String line) {
		try {
			String parts[] = line.split(",");
			Name competitorName = new Name(parts[1], parts[2], parts[3]);
			String competitorNumber = parts[0];
			int cnum = Integer.parseInt(competitorNumber);
			String competitorLevel = parts[4];
			String competitorCountry = parts[5];
			String competitorAge = parts[6];
			int cage = Integer.parseInt(competitorAge);
			String[] gS = parts[7].split(",");
			int gameScore = gS.length;
			int[] gamescore = new int[gameScore];
			for (int i = 0; i < gameScore; i++) {
				gamescore[i] = Integer.parseInt(gS[i]);
			}

			rrp3Competitor c = new rrp3Competitor(cnum, competitorName, competitorLevel, competitorCountry,cage,
					gamescore);
			this.add(c);
		}

		// catches for exceptions - both have been tested for functionality by altering
		// the input file
		catch (NumberFormatException ohno) {
			String error = "Number conversion error in '" + line + "'  - " + ohno.getMessage();
			System.out.println(error);
		} catch (ArrayIndexOutOfBoundsException ohshoot) {
			String error = "Not enough items in  : '" + line + "' index position : " + ohshoot.getMessage();
			System.out.println(error);

		}

	}

	/**
	 * Generates the String count from the input file
	 * 
	 * @return number of elements in the list
	 */

	public int getnumberOfCompetitors() {
		return competitorList.size();
	}

	/**
	 * Will find competitor based on competitor number
	 * 
	 * @param competitorNumber competitor number from the input list
	 * @return Short details and full details of requested competitor number
	 */
	// returns the objects with a specified id
	public String findBycompetitorNumber(int competitorNumber) {
		for (rrp3Competitor c : competitorList) {
			if (c.getcompetitorNumber() == (competitorNumber)) {
				return "\n" + "Short details: " + "\n" + c.getshortDetails();
			}
		}
		return "\nCompetitor " + competitorNumber + " does not exist. Please enter a valid competitor number.";
	}

	/**
	 * Will find maximum weighted average score in the list
	 * 
	 * @return maximum weighted average score value
	 */
	// create method to get maximum weighted AverageScore to get the winner
	public double getMaxweightedAverageScore() {
		double maxweightedAverageScore = 0;
		for (rrp3Competitor c : competitorList) {
			double weightedAverageScore = c.getweightedAverage();
			if (weightedAverageScore > maxweightedAverageScore) {
				maxweightedAverageScore = weightedAverageScore;
			}
		}
		return maxweightedAverageScore;
	}

	/**
	 * Will find the winner of the competition based on maximum weighted average
	 * score
	 * 
	 * @param competitorName the name of the competitor
	 * @return Name and details of the winner
	 */
	// return the winner
	public String findtheWinner(String competitorName) {
		String res = null;
		for (rrp3Competitor c : competitorList) {
			if (c.getweightedAverage() == (getMaxweightedAverageScore())) {

				return res = "Competitor " + c.getName().getFullName()
						+ " is the winner of Battle of Wits with the overall score of " + getMaxweightedAverageScore()
						+ ".\n" + "\nFollowing are the details of the winner: " + "\n" + c.getfullDetails();
			}
		}
		return res;

	}

	/**
	 * Will find the maximum age of participation
	 * 
	 * @return the maximum age amongst competitors
	 */
	// method to get maximum age of participation
	public int getMaxAge() {
		int maxAge = 0;
		for (rrp3Competitor c : competitorList) {
			int mxAge = c.getcompetitorAge();
			if (mxAge > maxAge) {
				maxAge = mxAge;
			}
		}
		return maxAge;
	}

	/**
	 * will generate frequency table of age of the competitors
	 * 
	 * @return frequency of competitor age
	 */
	// method to generate Age frequency report
	public String getAgeFrequencyReport() {
		int maxAge = getMaxAge();
		int[] freqAge = new int[maxAge];
		for (rrp3Competitor c : competitorList) {
			int g = c.getcompetitorAge();
			freqAge[g - 1]++;
		}
		String report = "";
		for (int i = 19; i < freqAge.length; i++) {
			report += "Age " + (i + 1) + " : " + freqAge[i] + "\n";
		}
		return report;
	}

	
	
	private ArrayList<String> compLevels = new ArrayList<>();

	/**
	 * will generate frequency of competitor level participation
	 * @return frequency of competitor levels
	 */

	public String getcompetitorLevelfrquency() {
		int[] freqLevel = new int[3];
		for (rrp3Competitor c : competitorList) {
			String g = c.getcompetitorLevel();
			compLevels.add(g);
		}
		String[] cLevels = { "Beginner", "Veteran", "Professional" };
		for (int i = 0; i < 3; i++) {
			int counts = Collections.frequency(compLevels, cLevels[i]);
			freqLevel[i] = counts;
		}
		String report = "The frequency of competitor level participation is as follows:" + "\n"
				+ "Beginner    Veteran     Professional\n";
		for (int i = 0; i < freqLevel.length; i++) {
			report += freqLevel[i] + "           ";
		}
		return report;

	}

	
	
	/**
	 * writes supplied text to file
	 * 
	 * @exception FileNotFoundException if an attempt to open the file denoted by a
	 *                                  specified pathname has failed
	 * @exception IOExceptionif         stream to file cannot be written to or
	 *                                  closed
	 * @param rrp3Report the name of the file to be written to
	 * @param report     the text to be written to file
	 */
	// writes text to file to generate report
	public void writeToFile(String rrp3Report, String report) {

		FileWriter fw;
		try {
			fw = new FileWriter(rrp3Report);
			fw.write("THE REPORT\n");
			fw.write("\n"
					+ "Competitor                              Level          Age Country    Scores             Overall Score\n");
			fw.write(report);
			fw.write("\nSTATISTICS:" + "\n" + "\n> The game of Battle of Wits has " + getnumberOfCompetitors()
					+ " competitors.");
			fw.write("\n" + "\n> " + findtheWinner(report) + "\n"
					+ "\n> The maximum age of particiaption in Battle of Wits is " + getMaxAge() + "." + "\n");
			fw.write("\n> The participation age frequency for Battle of Wits is as follows:" + "\n"
					+ getAgeFrequencyReport() + "\n");
			fw.write("> " + getcompetitorLevelfrquency());

			fw.close();
		}

		// if file not found give message and stop
		catch (FileNotFoundException fnf) {
			System.out.println(rrp3Report + " not found ");
			System.exit(0);
		}

		// stack trace here- stackoverflow - encountered this one too
		catch (IOException ioe) {
			ioe.printStackTrace();
			System.exit(1);
		}
	}

}
