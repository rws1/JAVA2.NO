import java.util.Scanner;

public class rrp3CompetitorManager {

	public void run() {

		rrp3CompetitorList c = new rrp3CompetitorList();

		c.readFile("rrp3CompetitorInput");

		String report = c.getAllCompetitors();

		c.writeToFile("rrp3CompetitorReport.txt", report);
		
		
		
			Scanner sc = new Scanner(System.in);
			System.out.print("\nPlease enter the competitor number from 100 to 110 to retrive information: ");
			try {
				int competitorNumber = sc.nextInt();
				System.out.println(c.findBycompetitorNumber(competitorNumber));
			} catch (Exception notfound) {
				System.out.println("\nCompetitor number invalid. Please enter a valid number");
			}
		    sc.close();
		    }

	
	}

